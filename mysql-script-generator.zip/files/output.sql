insert into TBL_EMPLOYEE (ID,NAME,AGE,BIRTH,INCOME,CREATION) values (UUID(),'Any Name Without Any Creativity',30,'1988-07-31',9876.54,'2020-11-30 22:35:00');
insert into TBL_EMPLOYEE (ID,NAME,AGE,BIRTH,INCOME,CREATION) values (UUID(),'Any Name Without Any Creativity',30,'1988-07-31',9876.54,'2020-11-30 22:35:00');
insert into TBL_EMPLOYEE (ID,NAME,AGE,BIRTH,INCOME,CREATION) values (UUID(),'Any Name Without Any Creativity',30,'1988-07-31',9876.54,'2020-11-30 22:35:00');
insert into TBL_EMPLOYEE (ID,NAME,AGE,BIRTH,INCOME,CREATION) values (UUID(),'Any Name Without Any Creativity',30,'1988-07-31',9876.54,'2020-11-30 22:35:00');
insert into TBL_EMPLOYEE (ID,NAME,AGE,BIRTH,INCOME,CREATION) values (UUID(),'Any Name Without Any Creativity',30,'1988-07-31',9876.54,'2020-11-30 22:35:00');
